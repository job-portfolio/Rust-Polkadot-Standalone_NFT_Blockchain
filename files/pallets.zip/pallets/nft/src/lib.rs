#![cfg_attr(not(feature = "std"), no_std)]

use codec::{Encode, Decode};
use sp_std::vec::Vec;
use sp_runtime::traits::Hash;
use frame_support::traits::Currency;
//use sp_runtime::Permill;

#[derive(Encode, Decode, Clone, Default, PartialEq)]
pub struct SaleInfo<Hash, BlockNumber, BalanceOf>{
	pub auction_id: Hash,
	pub price: BalanceOf,
	pub target: BlockNumber,
}

#[derive(Encode, Decode, Clone)]
pub struct SaleHistory<AccountId, BalanceOf>{
	pub block: u64,
	pub seller: AccountId,
	pub buyer: AccountId,
	pub price: BalanceOf,
	// pub copies: u32
}

#[derive(Encode, Decode, Clone, Default, PartialEq)]
pub struct NFT<AccountId, Hash, BlockNumber, BalanceOf>{
	pub id: Hash,
	pub creator: AccountId,
	pub royalty: u8,
	pub share: u8,
	pub data: Vec<u8>,
	pub sale_info: SaleInfo<Hash, BlockNumber, BalanceOf>,
	// pub copies: u32
	// sale_history | (See struct)
	// authenticity signature
	// legal rights | Enum: Commercial; Private; None
}

#[derive(Encode, Decode, Clone)]
pub struct Auction<AccountId, BlockNumber, BalanceOf>{
	pub creator: AccountId,
	// pub created: BlockNumber,
	pub seller: AccountId,
	pub share: u8,
	pub price: BalanceOf,
	pub royalty: u8,
	pub target: BlockNumber,		// target_block
	pub sample: Vec<u8>,			// display purposes (i.e. reduced resolution image)
	// pub copies: u32
}

// #[derive(Encode, Decode, Clone)]
// pub struct Song<AccountId>{
// 	pub artist: AccountId,
// 	pub royalty: u8,
// 	pub name: Vec<u8>,
// 	pub length: u8,
// 	pub description: Vec<u8>,
// 	pub cover: Vec<u8>,
// 	pub copies: u32,
// 	pub block: u64, // date of creation
// 	pub data: Vec<u8>,
// }

// #[derive(Encode, Decode, Clone)]
// pub struct Art<AccountId>{
// 	pub artist: AccountId,
// 	pub royalty: u8,
// 	pub name: Vec<u8>,
// 	// pub length: u8,
// 	pub description: Vec<u8>,
// 	pub cover: Vec<u8>,
// 	pub copies: u32, 
// 	pub block: u64, // date of creation
// 	pub data: Vec<u8>,
// }

pub use pallet::*;

#[frame_support::pallet]
pub mod pallet {

use frame_support::{dispatch::DispatchResult, pallet_prelude::*, traits::ExistenceRequirement};
	use frame_system::pallet_prelude::*;
use sp_runtime::{Percent, SaturatedConversion, traits::Saturating};
	use super::*;

	#[pallet::config]
	pub trait Config: frame_system::Config {
		type Event: From<Event<Self>> + IsType<<Self as frame_system::Config>::Event>;
		type Currency: Currency<Self::AccountId>;
	}

	type BalanceOf<T> = <<T as Config>::Currency as Currency<<T as frame_system::Config>::AccountId>>::Balance;

	pub type NFT_<T> = NFT<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;
	pub type Auction_<T> = Auction<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;
	pub type SaleInfo_<T> = SaleInfo<<T as frame_system::Config>::Hash, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;

	#[pallet::pallet]
	#[pallet::generate_store(pub(super) trait Store)]
	pub struct Pallet<T>(_);

	#[pallet::storage]
	#[pallet::getter(fn get_nft_count)]
	pub(super) type NFTCount<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, u16, ValueQuery>;

	#[pallet::storage]
	#[pallet::getter(fn get_multi_nft)]
	pub(super) type MultiNFTMap<T> = StorageMap<_, Blake2_128Concat, (<T as frame_system::Config>::AccountId, u16), NFT_<T>>;

	#[pallet::storage]
	#[pallet::getter(fn get_item)]
	pub(super) type AuctionHouse<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::Hash, Auction_<T>>;

	#[pallet::event]
	#[pallet::metadata(T::AccountId = "AccountId")]
	#[pallet::generate_deposit(pub(super) fn deposit_event)]
	pub enum Event<T: Config> {
		SomethingStored(u32, T::AccountId),
	}

	#[pallet::error]
	pub enum Error<T> {
		NoneValue,
		StorageOverflow,
		OwnershipError,
		ExistError,
		GetError,
		InsufficientFunds,
		RoyaltyOver100,
		NotForSale,
		PriceMismatch,
		AuctionExpired,
		IdentityError,
	}

	#[pallet::hooks]
	impl<T: Config> Hooks<BlockNumberFor<T>> for Pallet<T> {}

	#[pallet::call]
	impl<T:Config> Pallet<T> {
		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn mint(origin: OriginFor<T>, data: Vec<u8>, royalty: u8) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(royalty <= 100, Error::<T>::RoyaltyOver100);

			let nft_hash = T::Hashing::hash_of(&data);

			let nft = NFT {
				id: nft_hash,
				creator: caller.clone(),
				royalty,
				share: 100,
				data,
				sale_info: SaleInfo::default(),
			};

			let index = NFTCount::<T>::get(&caller);

			let new_index = index.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;

			MultiNFTMap::<T>::insert((&caller, index), nft);
			NFTCount::<T>::insert(&caller, new_index);

			//Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn burn(origin: OriginFor<T>, owner: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(&caller == &owner, Error::<T>::OwnershipError);

			// CHECK IF NFT IS IN AUCTION HOUSE AND REMOVE.
			
			MultiNFTMap::<T>::remove((&owner, index));

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn transfer(origin: OriginFor<T>, from: T::AccountId, to: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(&caller == &from, Error::<T>::OwnershipError);

			let mut nft = MultiNFTMap::<T>::get((&caller, index)).ok_or(Error::<T>::GetError)?;
			
			AuctionHouse::<T>::remove(nft.sale_info.auction_id);
			
			nft.sale_info = SaleInfo::default();

			let recipient_index = NFTCount::<T>::get(&to);
			
			MultiNFTMap::<T>::remove((&from, index));
			MultiNFTMap::<T>::insert((&to, recipient_index), nft);

			// increase nft count of buyer
			let new_recipient_index = recipient_index.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;

			NFTCount::<T>::insert(&to, new_recipient_index);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn transfer_internal(origin: OriginFor<T>, from: T::AccountId, to: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(&caller == &to, Error::<T>::IdentityError);

			let mut nft = MultiNFTMap::<T>::get((&from, index)).ok_or(Error::<T>::GetError)?;
			
			AuctionHouse::<T>::remove(nft.sale_info.auction_id);
			
			nft.sale_info = SaleInfo::default();

			let recipient_index = NFTCount::<T>::get(&to);
			
			MultiNFTMap::<T>::remove((&from, index));
			MultiNFTMap::<T>::insert((&to, recipient_index), nft);

			// increase nft count of buyer
			let new_recipient_index = recipient_index.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;

			NFTCount::<T>::insert(&to, new_recipient_index);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn sell(origin: OriginFor<T>, seller: T::AccountId, index: u16, price: BalanceOf<T>, sample: Vec<u8>, day: u8) -> DispatchResult {
			let caller = ensure_signed(origin)?;

			ensure!(&caller == &seller, Error::<T>::OwnershipError);

			let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or(Error::<T>::GetError)?;

			ensure!(nft != NFT::default(), Error::<T>::ExistError);
			
			if nft.sale_info != SaleInfo::default() {						// remove the NFT if it already exists on the auction house
				// INCLUDE: ensure auction house item is not null. Use Option
				// AuctionHouse::<T>::get(key)
				AuctionHouse::<T>::remove(nft.sale_info.auction_id);
				nft.sale_info = SaleInfo::default();
			}

			let mut block_delay: u32 = day.into();
			block_delay = block_delay * 28000;		
			block_delay = block_delay + 20;						// REMOVE THIS LINE AFTER TESTING

			let current_block_number = <frame_system::Pallet<T>>::block_number();

			let target_block = current_block_number + block_delay.into();

			let lot = Auction {
				creator: nft.creator.clone(),
				seller: seller.clone(),
				share: 100,
				price: price,
				royalty: nft.royalty.clone(),
				target: target_block,			// CHANGE THIS
				sample: sample,
			};

			let mut auction_id = T::Hashing::hash_of(&lot);

			// // CHECK FOR COLLISIONS
			// let auction_id = if AuctionHouse::<T>::get(auction_id) != null {
			// 	let collision = true;
			// 	while collision {
			//
			// 	}
			// } else {
			// 	T::Hashing::hash_of(&lot);
			// }; 

			let sale_info = SaleInfo {
				auction_id: auction_id,
				price: price,
				target: target_block,
			};

			nft.sale_info = sale_info.clone();		// !! I CAN REMOVE CLONE WHEN I REMOVE SALEINFOSTORE INSERT BELOW

			MultiNFTMap::<T>::insert((&caller, index), nft);

			AuctionHouse::<T>::insert(auction_id, lot);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn buy(origin: OriginFor<T>, buyer: T::AccountId, seller: T::AccountId, index: u16, price: BalanceOf<T>) -> DispatchResult {
			let caller = ensure_signed(origin.clone())?;

			ensure!(price < T::Currency::total_balance(&buyer), Error::<T>::InsufficientFunds);

			let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&seller, index)).ok_or(Error::<T>::GetError)?;

			// ensure!(nft.copies > 0)
			ensure!(nft.sale_info != SaleInfo::default(), Error::<T>::NotForSale);
			ensure!(nft.sale_info.price == price, Error::<T>::PriceMismatch);
			ensure!(nft.sale_info.target > <frame_system::Pallet<T>>::block_number(), Error::<T>::AuctionExpired);

			// AuctionHouse::<T>::remove(nft.sale_info.auction_id);
			// nft.sale_info = SaleInfo::default();

			// CREATE AN ENTRY IN SALES_HISTORY OF NFT: BUYER | SELLER | PRICE | BLOCK_NUMBER

			Pallet::<T>::transfer_internal(origin.clone(), seller.clone(), buyer.clone(), index.clone())?;		// TRANSFER NFT TO BUYER
			
			if nft.royalty == 0 {
				T::Currency::transfer(&buyer, &seller, price, ExistenceRequirement::AllowDeath)?;
			} else if nft.creator == seller {
				T::Currency::transfer(&buyer, &seller, price, ExistenceRequirement::AllowDeath)?;
			} else {
				let royalty: BalanceOf<T> = nft.royalty.saturated_into();
				
				let h: u8 = 100.into();
				let hundred: BalanceOf<T> = h.into();
				
				let s: u32 = 100.saturating_sub(nft.royalty.into());
				let sellers_proportion: BalanceOf<T> = s.saturated_into();

				let royalty_fee = (price * royalty) / hundred;
				let seller_fee = (price * sellers_proportion) / hundred;
				
				T::Currency::transfer(&buyer, &seller, seller_fee, ExistenceRequirement::KeepAlive)?;
				T::Currency::transfer(&buyer, &nft.creator, royalty_fee, ExistenceRequirement::KeepAlive)?;

				//let x = price * price;
				//let royalty_fund = (price * nft.royalty) / 100;
				//let seller_fund = (price * (100 - nft.royalty)) / 100;
				
				//let royalty_multiplier = Percent::from_rational(nft.royalty, 100);
				// TRANSFER ROYALTY TO CREATOR
				// TRANSFER (PRICE - ROYALTY) TO SELLER
			}

			// if nft.royalty == 0 {
			// 	T::Currency::transfer(&buyer, &seller, price, ExistenceRequirement::AllowDeath)?;
			// } else {
			// 	let royalty: BalanceOf<T> = nft.royalty.saturated_into();
				
			// 	let h: u8 = 100.into();
			// 	let hundred: BalanceOf<T> = h.into();
				
			// 	let s: u32 = 100.saturating_sub(nft.royalty.into());
			// 	let sellers_proportion: BalanceOf<T> = s.saturated_into();

			// 	let royalty_fee = (price * royalty) / hundred;
			// 	let seller_fee = (price * sellers_proportion) / hundred;
				
			// 	T::Currency::transfer(&buyer, &seller, seller_fee, ExistenceRequirement::AllowDeath)?;
			// 	T::Currency::transfer(&buyer, &nft.creator, royalty_fee, ExistenceRequirement::AllowDeath)?;

			// 	//let x = price * price;
			// 	//let royalty_fund = (price * nft.royalty) / 100;
			// 	//let seller_fund = (price * (100 - nft.royalty)) / 100;
				
			// 	//let royalty_multiplier = Percent::from_rational(nft.royalty, 100);
			// 	// TRANSFER ROYALTY TO CREATOR
			// 	// TRANSFER (PRICE - ROYALTY) TO SELLER
			// }

			//	IMPLEMENT FUNCTIONALITY TO BUY MULTIPLE COPIES.
			//		- CHECK MULTIPLE COPIES ARE AVAILABLE
			//		- FUNDS TRANSFERRED (INC. ROYALTY) = SINGLE PURCHASE * NUMBER OF COPIES 

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn cause_error(origin: OriginFor<T>, a: T::AccountId, b: T::AccountId) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(a == b, Error::<T>::StorageOverflow);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn revoke(origin: OriginFor<T>, owner: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			// FUNCTION:
			// REMOVES THE NFT FROM AUCTION HOUSE.

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn set_block_delay(origin: OriginFor<T>, block: T::BlockNumber) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			let current_block_number = <frame_system::Pallet<T>>::block_number();

			let block_delay: u32 = 10;

			let target_block = current_block_number + block_delay.into();

			ensure!(target_block < block, "fail");

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		//pub fn sell(origin: OriginFor<T>, seller: T::AccountId, index: u16, share: u8, price: u128, sample: Vec<u8>, day: u8) -> DispatchResult {
		pub fn sell_share(origin: OriginFor<T>, seller: T::AccountId, index: u16, share: u8, price: BalanceOf<T>, sample: Vec<u8>, day: u8) -> DispatchResult {
			let caller = ensure_signed(origin)?;

			// ensure!(&caller == &seller, "You do not own the NFT");

			// let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or("unable to acquire NFT object for transfer")?;

			// ensure!(nft != NFT::default(), "NFT does not exist");			// ENSURE NFT EXISTS
			// ensure!(nft.share >= share, "You do not own enough share");
			
			// if nft.sale_info != SaleInfo::default() {						// remove the NFT if it already exists on the auction house
			// 	// INCLUDE: ensure auction house item is not null. Use Option
			// 	// AuctionHouse::<T>::get(key)
			// 	AuctionHouse::<T>::remove(nft.sale_info.auction_id);
			// 	nft.sale_info = SaleInfo::default();
			// }

			// let mut block_delay: u32 = day.into();
			// block_delay = block_delay * 28000;		
			// block_delay = block_delay + 20;						// REMOVE THIS LINE AFTER TESTING

			// let current_block_number = <frame_system::Pallet<T>>::block_number();

			// let target_block = current_block_number + block_delay.into();

			// let lot = Auction {
			// 	creator: nft.creator.clone(),
			// 	seller: seller.clone(),
			// 	share: share,
			// 	price: price,
			// 	royalty: nft.royalty.clone(),
			// 	target: target_block,			// CHANGE THIS
			// 	sample: sample,
			// };

			// let mut auction_id = T::Hashing::hash_of(&lot);

			// // // CHECK FOR COLLISIONS
			// // let auction_id = if AuctionHouse::<T>::get(auction_id) != null {
			// // 	let collision = true;
			// // 	while collision {
			// //
			// // 	}
			// // } else {
			// // 	T::Hashing::hash_of(&lot);
			// // }; 

			// let sale_info = SaleInfo {
			// 	auction_id: auction_id,
			// 	price: price,
			// 	target: target_block,
			// };

			// nft.sale_info = sale_info.clone();		// !! I CAN REMOVE CLONE WHEN I REMOVE SALEINFOSTORE INSERT BELOW

			// MultiNFTMap::<T>::insert((&caller, index), nft);

			// AuctionHouse::<T>::insert(auction_id, lot);

			// // ALLOW THE SELLING OF MULTIPLE SHARES: REQUIRED - A REMAINING SHARE FIELD
			// // EACH ACCOUNT SHOULD HAVE ITS OWN STORAGEMAP SHOWING WHAT NFTS ARE FOR SALE IN THE AUCTION HOUSE, THIS WAY MULTIPLE SHARE SALES CAN BE ASSESSED.

			// // Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn buy_share(origin: OriginFor<T>, owner: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			// NOT SURE ABOUT THIS FUNCTION.
			// PERHAPS HAVE ONLY A BUY FUNCTION AND A SELL FUNCTION WITH SHARE OPTION

			// FUNCTION:
			// ALLOW A USER TO REQUEST TO BUY A PROPORTION OF THE NFT ON SALE.
			// ONLY WHEN 100% OF THE SHARE FOR SALE HAS BEEN 
			// THE FUNCTION WAITS UNTIL A 
			// BIDDERS FUNDS MUST BE LOCKED?
			// ON THE SELL FUNCTION - OWNER SETS:
			//	- ALLOW TO SELL SHARES
			//  - ALLOW TO SELL THREE SHARE 
			// PRIORITISES PEOPLE WHO WANT TO OWN LOWER SHARES.

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		pub fn transfer_share(origin: OriginFor<T>, from: T::AccountId, to: T::AccountId, index: u16, share: u8) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			// ensure!(&caller == &from, "You do not own the NFT");

			// let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or("unable to acquire NFT object for transfer")?;

			// ensure!(nft.share >= share, "You do not own enough share");

			// let share_remaining = nft.share.checked_sub(share).ok_or("unable to reduce share")?;

			// let mut nft_buyer = nft.clone();

			// nft.share = share_remaining;
			// nft_buyer.share = share;

			// let recipient_index = NFTCount::<T>::get(&to);
			
			// MultiNFTMap::<T>::insert((&from, index), nft);
			// MultiNFTMap::<T>::insert((&to, recipient_index), nft_buyer);

			// // increase nft count of buyer
			// let new_recipient_index = recipient_index.checked_add(1).ok_or("u16 overflow found when incrementing recipient index")?;

			// NFTCount::<T>::insert(&to, new_recipient_index);

			// // Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}
		//
		//
		//
		//
		//
		//
		//
		//
		//
		//
		//
		//
		//
		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn do_addr(origin: OriginFor<T>, something: u32) -> DispatchResult {
		// 	let who = ensure_signed(origin)?;

		// 	<Addr<T>>::put(&who);

		// 	Self::deposit_event(Event::SomethingStored(something, who));

		// 	Ok(())
		// }
		
		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn do_something(origin: OriginFor<T>, something: u32) -> DispatchResult {
		// 	let who = ensure_signed(origin)?;

		// 	<Something<T>>::put(something);

		// 	Self::deposit_event(Event::SomethingStored(something, who));

		// 	Ok(())
		// }

		// #[pallet::weight(10_000 + T::DbWeight::get().reads_writes(1,1))]
		// pub fn cause_error(origin: OriginFor<T>) -> DispatchResult {
		// 	let _who = ensure_signed(origin)?;

		// 	match <Something<T>>::get() {

		// 		None => Err(Error::<T>::NoneValue)?,
		// 		Some(old) => {
		// 			let new = old.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;
		// 			<Something<T>>::put(new);
		// 			Ok(())
		// 		},
		// 	}
		// }
		//
		// #############
		// BUILD GUIDELINES:
		// #############
		// File imported through mint function call
		// Hash of file created.
		//
		// Store file on IPFS
		// Get IPFS storage location
		// Store IPFS location data in ipfs_url
		//
		// create object: owner | hash of data | IPFS location
		//
		// encrypt IPFS location (using a password) and store the encrypted IPFS location
		// encrypt the IPFS data prior to loading on IPFS
		//
		// #############
		// STRUCTS:
		// #############
		// #[derive(Encode, Decode)]
		// pub struct TokenInfoTwo<AccountId, Hash>{
		// 	pub owner: AccountId,
		// 	pub nft_id: Hash,
		// 	pub ipfs_url: Vec<u8>,
		// }
		// #[derive(Encode, Decode)]
		// pub struct TokenInfo<AccountId, Hash>{
		// 	pub owner: AccountId,
		// 	pub nft_id: Hash,
		// }
		// #[derive(Encode, Decode)]
		// pub struct AcctInfo<AccountId>{
		// 	pub owner: AccountId,
		// }
		// #[derive(Encode, Decode)]
		// pub struct HshInfo<Hash>{
		// 	pub nft_id: Hash,
		// }
		// #[derive(Encode, Decode)]
		// pub struct TokenInfoFinal{
		// 	pub ipfs_id: Vec<u8>,
		// }
		//
		// #############
		// TYPES:
		// #############
		// pub type TokenInfoOf<T> = TokenInfo<<T as frame_system::Config>::AccountId, <T as Config>::LovelyNumber>;
		// pub type TokenInfoOf<T> = TokenInfo<<T as frame_system::Config>::AccountId, <T as Config>::TokenData>;
		// pub type TokenInfoOf<T> = TokenInfo<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash>;
		// pub type TokenInfoTwoOf<T> = TokenInfoTwo<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash>;
		// pub type AcctInfoOf<T> = AcctInfo<<T as frame_system::Config>::AccountId>;
		// pub type HshInfoOf<T> = HshInfo<<T as frame_system::Config>::Hash>;
		// pub type TokenInfoFinalOf = TokenInfoFinal;
		// pub type NFT_<T> = NFT<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash>;
		// type LovelyNumber: Get<u32>;

		// #############
		// STORAGE:
		// #############
		// #[pallet::storage]
		// #[pallet::getter(fn something)]
		// pub type Something<T> = StorageValue<_, u32>;

		// #[pallet::storage]
		// #[pallet::getter(fn get_addr)]	
		// pub type Addr<T> = StorageValue<_, <T as frame_system::Config>::AccountId>;

		// #[pallet::storage]
		// #[pallet::getter(fn some_map)]
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, TokenInfoOf<T>>;
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, u32>;
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, T::AccountId, u32, ValueQuery>;

		// #[pallet::storage]
		// pub(super) type SomeDoubleMap<T> = StorageDoubleMap<_, Blake2_128Concat, u32, Blake2_128Concat, <T as frame_system::Config>::AccountId, u32>;
		// pub(super) type SomeDoubleMap<T> = StorageDoubleMap<_, Blake2_128Concat, u32, Blake2_128Concat, T::AccountId, u32, ValueQuery>;

		// #[pallet::storage]
		// #[pallet::getter(fn some_map)]
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, TokenInfoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn some_map_two)]
		// pub(super) type SomeMapTwo<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, TokenInfoTwoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn acct_map)]
		// pub(super) type AcctMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, AcctInfoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn hsh_map)]
		// pub(super) type HshMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, HshInfoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn main_map)]
		// pub(super) type MainMap<T> = StorageMap<_, Blake2_128Concat, (<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash), TokenInfoFinalOf>;

		// #[pallet::storage]
		// #[pallet::getter(fn get_NFT)]
		// pub(super) type NFTMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, NFT_<T>>;

		// #############
		// MINT:
		// #############
		// NFTMap::<T>::insert(&caller, &nft);

		// #############
		// MINT FUNCTION: POP AND SWAP
		// #############
		// let last_index_value = NFTCount::<T>::get(&caller);

		// if index != last_index_value {
		// 	let nft_last = MultiNFTMap::<T>::get((&caller, last_index_value)).ok_or("unable to acquire last NFT object for pop and swap")?;
		// 	let nft_elsewhere = MultiNFTMap::<T>::get((&caller, index)).ok_or("unable to acquire last NFT object for pop and swap")?;
		// 	MultiNFTMap::<T>::insert((to.clone(), last_index_value), nft_elsewhere);
		// 	MultiNFTMap::<T>::insert((to.clone(), index), nft_last);
		// }
		// #############
		// MINT FUNCTION: TRANSFER
		// #############
		// ##################################
		// IF EMPTY LIST ELEMENTS ARE NOT CREATED BY ::remove THEN THIS SECTION OF CODE IS NOT NEEDED
		// // the sale created an empty element in the sellers nft list, move the last nft into this empty element.
		// let last_index_value = NFTCount::<T>::get(&caller);
		//
		// if index != last_index_value {
		// 	let last_nft = MultiNFTMap::<T>::get((&from, last_index_value)).ok_or("unable to acquire last NFT object for pop and swap")?;
		// 	MultiNFTMap::<T>::remove((&from, last_index_value));
		// 	MultiNFTMap::<T>::insert((&from, index), last_nft);
		// }
		//
		// // decrease nft count of seller
		// let reduced_index = last_index_value.checked_sub(1).ok_or("u16 overflow found when incrementing recipient index")?;
		// NFTCount::<T>::insert(&from, reduced_index);
		// ##################################

		// #############
		// GENERAL INFORMATION
		// #############
		// DURATION
			// 1 BLOCK = 3 SECONDS
			// 20 BLOCK = 1 MINUTE
			// 1,200 BLOCK = 1 HOUR
			// 28,000 BLOCK = 1 DAY		24 HOURS
			// 201,800 BLOCK = 7 DAYS	168 HOURS
			// 864,000 = 30 DAYS		720 HOURS
	}
}
