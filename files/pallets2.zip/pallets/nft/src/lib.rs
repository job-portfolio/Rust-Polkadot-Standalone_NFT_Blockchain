#![cfg_attr(not(feature = "std"), no_std)]

use codec::{Encode, Decode};
use sp_std::vec::Vec;
use sp_runtime::traits::Hash;
use frame_support::traits::Currency;

#[derive(Encode, Decode, Clone, Default, PartialEq)]
pub struct SaleInfo<Hash, BlockNumber, BalanceOf>{
	pub auction_id: Hash,
	pub price: BalanceOf,
	pub target: BlockNumber,
	pub copies: u16,
}

#[derive(Encode, Decode, Clone, Default, PartialEq)]
pub struct SaleHistory<BlockNumber, AccountId, BalanceOf>{
	pub block: BlockNumber,
	pub seller: AccountId,
	pub buyer: AccountId,
	pub price: BalanceOf,
	pub copies: u16,
}

#[derive(Encode, Decode, Clone, Default, PartialEq)]
pub struct NFTv2<AccountId, Hash, BlockNumber, BalanceOf>{
	pub creator: AccountId,
	//pub owner: AccountId,
	pub date: BlockNumber,
	pub royalty: u8,
	pub share: u8,
	pub data: Vec<u8>,
	pub copies: u16,
	//pub sale_info: SaleInfo<Hash, BlockNumber, BalanceOf>,
	pub sale_history: SaleHistory<BlockNumber, AccountId, BalanceOf>,
	pub salt: u32,
	pub price: BalanceOf,
	pub target: BlockNumber,
	pub quantity: u16,

	// authenticity signature
	// legal rights | Enum: Commercial; Private; None
	// music -> track-length
	// art -> description
	// sport ->
	// gaming ->
}

// #[derive(Encode, Decode, Clone, Default, PartialEq)]
// pub struct NFTv2<AccountId, Hash, BlockNumber, BalanceOf>{
// 	//pub id: Hash,
// 	pub creator: AccountId,
// 	pub date: BlockNumber,
// 	pub royalty: u8,
// 	pub share: u8,
// 	pub data: Vec<u8>,
// 	pub copies: u16,
// 	pub sale_info: SaleInfo<Hash, BlockNumber, BalanceOf>,
// 	pub sale_history: SaleHistory<BlockNumber, AccountId, BalanceOf>,
// 	pub salt: u32,
// 	// authenticity signature
// 	// legal rights | Enum: Commercial; Private; None
// 	// music -> track-length
// 	// art -> description
// 	// sport ->
// 	// gaming ->
// }

#[derive(Encode, Decode, Clone, Default, PartialEq)]
pub struct NFT<AccountId, Hash, BlockNumber, BalanceOf>{
	pub id: Hash,
	pub creator: AccountId,
	pub date: BlockNumber,
	pub royalty: u8,
	pub share: u8,
	pub data: Vec<u8>,
	pub copies: u16,
	pub sale_info: SaleInfo<Hash, BlockNumber, BalanceOf>,
	pub sale_history: SaleHistory<BlockNumber, AccountId, BalanceOf>,
	// authenticity signature
	// legal rights | Enum: Commercial; Private; None
	// music -> track-length
	// art -> description
	// sport ->
	// gaming ->
}

#[derive(Encode, Decode, Clone)]
pub struct Auction<AccountId, BlockNumber, BalanceOf>{
	pub creator: AccountId,
	pub seller: AccountId,
	pub share: u8,
	pub price: BalanceOf,
	pub royalty: u8,
	pub target: BlockNumber,
	pub sample: Vec<u8>,
	pub copies: u16,
	pub date: BlockNumber,
	pub sale_history: SaleHistory<BlockNumber, AccountId, BalanceOf>,
}

pub use pallet::*;

#[frame_support::pallet]
pub mod pallet {

use frame_support::{dispatch::DispatchResult, pallet_prelude::*, traits::ExistenceRequirement};
use frame_system::pallet_prelude::*;
use sp_runtime::{SaturatedConversion, traits::Saturating, print};
use super::*;

	#[pallet::config]
	pub trait Config: frame_system::Config {
		type Event: From<Event<Self>> + IsType<<Self as frame_system::Config>::Event>;
		type Currency: Currency<Self::AccountId>;
	}

	type BalanceOf<T> = <<T as Config>::Currency as Currency<<T as frame_system::Config>::AccountId>>::Balance;

	pub type NFT_<T> = NFT<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;
	pub type NFTv2_<T> = NFTv2<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;
	pub type Auction_<T> = Auction<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;
	pub type SaleInfo_<T> = SaleInfo<<T as frame_system::Config>::Hash, <T as frame_system::Config>::BlockNumber, BalanceOf<T>>;
	pub type SaleHistory_<T> = SaleHistory<<T as frame_system::Config>::BlockNumber, <T as frame_system::Config>::AccountId, BalanceOf<T>>;

	#[pallet::pallet]
	#[pallet::generate_store(pub(super) trait Store)]
	pub struct Pallet<T>(_);

	#[pallet::storage]
	#[pallet::getter(fn get_nft_count)]
	pub(super) type NFTCount<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, u16, ValueQuery>;

	#[pallet::storage]
	#[pallet::getter(fn get_multi_nft)]
	pub(super) type MultiNFTMap<T> = StorageMap<_, Blake2_128Concat, (<T as frame_system::Config>::AccountId, u16), NFT_<T>>;

	#[pallet::storage]
	#[pallet::getter(fn get_item)]
	pub(super) type AuctionHouse<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::Hash, Auction_<T>>;

	// =================================================================================
	// == Global

	#[pallet::storage]
	#[pallet::getter(fn get_record)]
	pub(super) type Database<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::Hash, (u16, <T as frame_system::Config>::AccountId)>;

	#[pallet::storage]
	#[pallet::getter(fn get_count)]
	pub(super) type Counter<T> = StorageValue<_, u128, ValueQuery>;

	#[pallet::storage]
	#[pallet::getter(fn get_next)]
	pub(super) type NextCopy<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::Hash, u32>;

	// =================================================================================

	#[pallet::storage]
	#[pallet::getter(fn get_lot)]
	pub(super) type AuctionH<T> = StorageMap<_, Blake2_128Concat, (<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash, u16), NFTv2_<T>>;

	#[pallet::storage]
	#[pallet::getter(fn get_expired)]
	pub(super) type GarbageCollector<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::BlockNumber, <T as frame_system::Config>::Hash>;

	// =================================================================================
	// == Local

	#[pallet::storage]
	#[pallet::getter(fn get_nft)]
	pub(super) type NFTs<T> = StorageMap<_, Blake2_128Concat, (<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash, u16), NFTv2_<T>>;

	// #[pallet::storage]
	// #[pallet::getter(fn get_item)]
	// pub(super) type History<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::BlockNumber, SaleHistory_<T>>;

	#[pallet::event]
	#[pallet::metadata(T::AccountId = "AccountId")]
	#[pallet::generate_deposit(pub(super) fn deposit_event)]
	pub enum Event<T: Config> {
		SomethingStored(u32, T::AccountId),
	}

	#[pallet::error]
	pub enum Error<T> {
		NoneValue,
		StorageOverflow,
		OwnershipError,
		ExistError,
		GetError,
		InsufficientFunds,
		InsufficientCopies,
		RoyaltyOver100,
		NotForSale,
		PriceMismatch,
		CopiesMismatch,
		CopyLimitExceeded,
		AuctionExpired,
		IdentityError,
	}

	#[pallet::hooks]
	impl<T: Config> Hooks<BlockNumberFor<T>> for Pallet<T> {}

	#[pallet::call]
	impl<T:Config> Pallet<T> {
		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn mint(origin: OriginFor<T>, data: Vec<u8>, copies: u16, royalty: u8) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(royalty <= 100, Error::<T>::RoyaltyOver100);
			ensure!(copies <= 1000, Error::<T>::CopyLimitExceeded);

			let mut nft= NFTv2 {
				creator: caller.clone(),
				date: <frame_system::Pallet<T>>::block_number(),
				royalty,
				share: 100,
				data,
				copies,
				//sale_info: SaleInfo::default(),
				sale_history: SaleHistory::default(),
				salt: 0,
				price: BalanceOf::default(),
				target: T::BlockNumber::default(),
				quantity: 0,
			};

			// let mut nft= NFTv2 {
			// 	creator: caller.clone(),
			// 	date: <frame_system::Pallet<T>>::block_number(),
			// 	royalty,
			// 	share: 100,
			// 	data,
			// 	copies,
			// 	sale_info: SaleInfo::default(),
			// 	sale_history: SaleHistory::default(),
			// 	salt: 0,
			// };

			let mut id = T::Hashing::hash_of(&nft);

			while Database::<T>::get(id) != None {						// COLLISION DETECTION ACROSS DATABASE
				
				nft.salt = nft.salt + 1;
				id = T::Hashing::hash_of(&nft);
			}

			if copies == 0 {
				Database::<T>::insert(id, (1, &caller));
				Counter::<T>::put(Counter::<T>::get() + 1);
				NextCopy::<T>::insert(id, 2);

				NFTs::<T>::insert((&caller, id, 0), &nft);
			} else {
				for copy in 1..=copies{
					Database::<T>::insert(id, (copy, &caller));
					NFTs::<T>::insert((&caller, id, copy), &nft);
				}
				Counter::<T>::put(Counter::<T>::get() + copies as u128);
			}

			//Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn query_content(origin: OriginFor<T>, hash: T::Hash) -> DispatchResult {
			let caller = ensure_signed(origin)?;

			if Database::<T>::get(hash) == None {
				frame_support::debug(&1);
				print("EQUALS NONE");
			} else {
				frame_support::debug(&0);
				print("EQUALS SOME");
			}

			Ok(())

		}
		


		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn burn(origin: OriginFor<T>, owner: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(&caller == &owner, Error::<T>::OwnershipError);

			// CHECK IF NFT IS IN AUCTION HOUSE AND REMOVE.
			
			MultiNFTMap::<T>::remove((&owner, index));

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn transfer(origin: OriginFor<T>, from: T::AccountId, to: T::AccountId, index: u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(&caller == &from, Error::<T>::OwnershipError);

			let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or(Error::<T>::GetError)?;
			
			AuctionHouse::<T>::remove(nft.sale_info.auction_id);
			
			nft.sale_info = SaleInfo::default();

			let recipient_index = NFTCount::<T>::get(&to);
			
			MultiNFTMap::<T>::remove((&from, index));
			MultiNFTMap::<T>::insert((&to, recipient_index), nft);

			// increase nft count of buyer
			let new_recipient_index = recipient_index.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;

			NFTCount::<T>::insert(&to, new_recipient_index);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn transfer_internal(origin: OriginFor<T>, from: T::AccountId, to: T::AccountId, index: u16, copies:u16) -> DispatchResult {
			let caller = ensure_signed(origin)?;
			
			ensure!(&caller == &to, Error::<T>::IdentityError);

			let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&from, index)).ok_or(Error::<T>::GetError)?;
			
			let mut lot: Auction_<T> = AuctionHouse::<T>::get(nft.sale_info.auction_id).ok_or(Error::<T>::GetError)?;

			let recipient_index = NFTCount::<T>::get(&to);

			let sale_history: SaleHistory_<T> = SaleHistory {
				block: <frame_system::Pallet<T>>::block_number(),
				seller: from.clone(),
				buyer: to.clone(),
				price: nft.sale_info.price.clone(),
				copies,
			};

			if copies == lot.copies {
				AuctionHouse::<T>::remove(nft.sale_info.auction_id);

				nft.sale_info = SaleInfo::default();
				nft.sale_history = sale_history;

				MultiNFTMap::<T>::remove((&from, index));
				MultiNFTMap::<T>::insert((&to, recipient_index), nft);

			} else {
				lot.copies = lot.copies - copies;										// 3   (10 - 7)
				AuctionHouse::<T>::insert(nft.sale_info.auction_id, &lot);		// RIGHT AMOUNT
				
				let mut sellers_nft = nft.clone();
				
				sellers_nft.copies = sellers_nft.copies - copies;	// 7, should be 3
				sellers_nft.sale_info.copies = sellers_nft.sale_info.copies - copies;	// 10, should be 3

				nft.copies = copies;	// 3, should be 7
				nft.sale_info = SaleInfo::default();
				nft.sale_history = sale_history;

				MultiNFTMap::<T>::insert((&from, index), sellers_nft);
				MultiNFTMap::<T>::insert((&to, recipient_index), nft);

			}

			// increase nft count of buyer
			let new_recipient_index = recipient_index.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;

			NFTCount::<T>::insert(&to, new_recipient_index);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn sell(origin: OriginFor<T>, seller: T::AccountId, index: u16, price: BalanceOf<T>, sample: Vec<u8>, copies: u16, day: u8) -> DispatchResult {
			let caller = ensure_signed(origin)?;

			ensure!(&caller == &seller, Error::<T>::OwnershipError);

			let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or(Error::<T>::GetError)?;

			ensure!(nft != NFT::default(), Error::<T>::ExistError);
			ensure!(nft.copies >= copies, Error::<T>::InsufficientCopies);
			
			if nft.sale_info != SaleInfo::default() {						// remove the NFT if it already exists on the auction house
				// INCLUDE: ensure auction house item is not null. Use Option
				// AuctionHouse::<T>::get(key)
				AuctionHouse::<T>::remove(nft.sale_info.auction_id);
				nft.sale_info = SaleInfo::default();
			}

			let mut block_delay: u32 = day.into();
			block_delay = block_delay * 28000;		
			block_delay = block_delay + 20;						// REMOVE THIS LINE AFTER TESTING

			let current_block_number = <frame_system::Pallet<T>>::block_number();

			let target_block = current_block_number + block_delay.into();

			let lot = Auction {
				creator: nft.creator.clone(),
				seller: seller.clone(),
				share: 100,
				price,
				royalty: nft.royalty.clone(),
				target: target_block,			// CHANGE THIS
				sample,
				copies,
				date: <frame_system::Pallet<T>>::block_number(),
				sale_history: nft.sale_history.clone(),
			};

			let mut auction_id = T::Hashing::hash_of(&lot);

			// // CHECK FOR COLLISIONS
			// TO LEARN HOW TO DO THIS: WRITE A FUNCTION WHAT QUERIES AN EMPTY AUCTION HOUSE ITEM, CHECK IF EMPTY AND RETURNS TRUE.
			// let auction_id = if AuctionHouse::<T>::get(auction_id) != null {
			// 	let collision = true;
			// 	while collision {
			//
			// 	}
			// } else {
			// 	T::Hashing::hash_of(&lot);
			// }; 

			let sale_info = SaleInfo {
				auction_id,
				price,
				target: target_block,
				copies,
			};

			nft.sale_info = sale_info.clone();		// !! I CAN REMOVE CLONE WHEN I REMOVE SALEINFOSTORE INSERT BELOW

			MultiNFTMap::<T>::insert((&caller, index), nft);

			AuctionHouse::<T>::insert(auction_id, lot);

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		#[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		fn buy(origin: OriginFor<T>, buyer: T::AccountId, seller: T::AccountId, index: u16, price: BalanceOf<T>, copies: u16) -> DispatchResult {
			let caller = ensure_signed(origin.clone())?;

			let total_cost = price * copies.saturated_into();	// IMPLEMENT SAFE MATH - checked_mul or saturating_mul

			ensure!(total_cost < T::Currency::total_balance(&buyer), Error::<T>::InsufficientFunds);
			// ensure!(price < T::Currency::total_balance(&buyer), Error::<T>::InsufficientFunds);

			let nft: NFT_<T> = MultiNFTMap::<T>::get((&seller, index)).ok_or(Error::<T>::GetError)?;

			ensure!(nft.sale_info != SaleInfo::default(), Error::<T>::NotForSale);
			ensure!(nft.sale_info.price == price, Error::<T>::PriceMismatch);
			ensure!(nft.sale_info.target > <frame_system::Pallet<T>>::block_number(), Error::<T>::AuctionExpired);
			ensure!(nft.copies >= copies, Error::<T>::InsufficientCopies);
			
			let auction_item: Auction_<T> = AuctionHouse::<T>::get(nft.sale_info.auction_id).ok_or(Error::<T>::GetError)?;
			
			ensure!(auction_item.copies >= copies, Error::<T>::InsufficientCopies);
			ensure!(auction_item.copies == nft.sale_info.copies, Error::<T>::CopiesMismatch);

			// CREATE AN ENTRY IN SALES_HISTORY OF NFT: BUYER | SELLER | PRICE | BLOCK_NUMBER

			Pallet::<T>::transfer_internal(origin.clone(), seller.clone(), buyer.clone(), index.clone(), copies.clone())?;		// TRANSFER NFT TO BUYER
			
			if nft.royalty == 0 {
				T::Currency::transfer(&buyer, &seller, total_cost, ExistenceRequirement::AllowDeath)?;
			} else if nft.creator == seller {
				T::Currency::transfer(&buyer, &seller, total_cost, ExistenceRequirement::AllowDeath)?;
			} else {
				let royalty: BalanceOf<T> = nft.royalty.saturated_into();
				
				let h: u8 = 100.into();
				let hundred: BalanceOf<T> = h.into();
				
				let s: u32 = 100.saturating_sub(nft.royalty.into());
				let sellers_proportion: BalanceOf<T> = s.saturated_into();

				let royalty_fee = (total_cost * royalty) / hundred;
				let seller_fee = (total_cost * sellers_proportion) / hundred;
				
				T::Currency::transfer(&buyer, &seller, seller_fee, ExistenceRequirement::KeepAlive)?;
				T::Currency::transfer(&buyer, &nft.creator, royalty_fee, ExistenceRequirement::KeepAlive)?;

				// Mathematics explained
				// 		Amount payable to creator: (price * nft.royalty) / 100;
				// 		Amount payable to seller:  (price * (100 - nft.royalty)) / 100;
			}

			// if nft.royalty == 0 {
			// 	T::Currency::transfer(&buyer, &seller, price, ExistenceRequirement::AllowDeath)?;
			// } else if nft.creator == seller {
			// 	T::Currency::transfer(&buyer, &seller, price, ExistenceRequirement::AllowDeath)?;
			// } else {
			// 	let royalty: BalanceOf<T> = nft.royalty.saturated_into();
				
			// 	let h: u8 = 100.into();
			// 	let hundred: BalanceOf<T> = h.into();
				
			// 	let s: u32 = 100.saturating_sub(nft.royalty.into());
			// 	let sellers_proportion: BalanceOf<T> = s.saturated_into();

			// 	let royalty_fee = (price * royalty) / hundred;
			// 	let seller_fee = (price * sellers_proportion) / hundred;
				
			// 	T::Currency::transfer(&buyer, &seller, seller_fee, ExistenceRequirement::KeepAlive)?;
			// 	T::Currency::transfer(&buyer, &nft.creator, royalty_fee, ExistenceRequirement::KeepAlive)?;

			// 	// Mathematics explained
			// 	// 		Amount payable to creator: (price * nft.royalty) / 100;
			// 	// 		Amount payable to seller:  (price * (100 - nft.royalty)) / 100;
			// }

			//	IMPLEMENT FUNCTIONALITY TO BUY MULTIPLE COPIES.
			//		- CHECK MULTIPLE COPIES ARE AVAILABLE
			//		- FUNDS TRANSFERRED (INC. ROYALTY) = SINGLE PURCHASE * NUMBER OF COPIES 

			// Self::deposit_event(Event::SomethingStored(something, caller));

			Ok(())
		}

		// ==============================================================================================
		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// fn mintX(origin: OriginFor<T>, data: Vec<u8>, copies: u16, royalty: u8) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;
			
		// 	ensure!(royalty <= 100, Error::<T>::RoyaltyOver100);

		// 	let id = T::Hashing::hash_of(&data);

		// 	// COLLISION DETECTION ACROSS DATABASE

		// 	let nft = NFT {
		// 		id: id.clone(),
		// 		creator: caller.clone(),
		// 		date: <frame_system::Pallet<T>>::block_number(),
		// 		royalty,
		// 		share: 100,
		// 		data,
		// 		copies,
		// 		sale_info: SaleInfo::default(),
		// 		sale_history: SaleHistory::default(),
		// 	};

		// 	let index = NFTCount::<T>::get(&caller);

		// 	let new_index = index.checked_add(1).ok_or(Error::<T>::StorageOverflow)?;

		// 	MultiNFTMap::<T>::insert((&caller, index), nft);
		// 	NFTCount::<T>::insert(&caller, new_index);

		// 	//Self::deposit_event(Event::SomethingStored(something, caller));

		// 	Ok(())
		// }
		// ==============================================================================================

		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn cause_error(origin: OriginFor<T>, a: T::AccountId, b: T::AccountId) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;
			
		// 	ensure!(a == b, Error::<T>::StorageOverflow);

		// 	// Self::deposit_event(Event::SomethingStored(something, caller));

		// 	Ok(())
		// }

		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn revoke(origin: OriginFor<T>, owner: T::AccountId, index: u16) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;
			
		// 	// FUNCTION:
		// 	// REMOVES THE NFT FROM AUCTION HOUSE.

		// 	// Self::deposit_event(Event::SomethingStored(something, caller));

		// 	Ok(())
		// }

		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn set_block_delay(origin: OriginFor<T>, block: T::BlockNumber) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;
			
		// 	let current_block_number = <frame_system::Pallet<T>>::block_number();

		// 	let block_delay: u32 = 10;

		// 	let target_block = current_block_number + block_delay.into();

		// 	ensure!(target_block < block, "fail");

		// 	Ok(())
		// }

		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// //pub fn sell(origin: OriginFor<T>, seller: T::AccountId, index: u16, share: u8, price: u128, sample: Vec<u8>, day: u8) -> DispatchResult {
		// pub fn sell_share(origin: OriginFor<T>, seller: T::AccountId, index: u16, share: u8, price: BalanceOf<T>, sample: Vec<u8>, day: u8) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;

		// 	ensure!(&caller == &seller, "You do not own the NFT");

		// 	let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or("unable to acquire NFT object for transfer")?;

		// 	ensure!(nft != NFT::default(), "NFT does not exist");			// ENSURE NFT EXISTS
		// 	ensure!(nft.share >= share, "You do not own enough share");
			
		// 	if nft.sale_info != SaleInfo::default() {						// remove the NFT if it already exists on the auction house
		// 		// INCLUDE: ensure auction house item is not null. Use Option
		// 		// AuctionHouse::<T>::get(key)
		// 		AuctionHouse::<T>::remove(nft.sale_info.auction_id);
		// 		nft.sale_info = SaleInfo::default();
		// 	}

		// 	let mut block_delay: u32 = day.into();
		// 	block_delay = block_delay * 28000;		
		// 	block_delay = block_delay + 20;						// REMOVE THIS LINE AFTER TESTING

		// 	let current_block_number = <frame_system::Pallet<T>>::block_number();

		// 	let target_block = current_block_number + block_delay.into();

		// 	let lot = Auction {
		// 		creator: nft.creator.clone(),
		// 		seller: seller.clone(),
		// 		share: share,
		// 		price: price,
		// 		royalty: nft.royalty.clone(),
		// 		target: target_block,			// CHANGE THIS
		// 		sample: sample,
		// 	};

		// 	let mut auction_id = T::Hashing::hash_of(&lot);

		// 	// // CHECK FOR COLLISIONS
		// 	// let auction_id = if AuctionHouse::<T>::get(auction_id) != null {
		// 	// 	let collision = true;
		// 	// 	while collision {
		// 	//
		// 	// 	}
		// 	// } else {
		// 	// 	T::Hashing::hash_of(&lot);
		// 	// }; 

		// 	let sale_info = SaleInfo {
		// 		auction_id: auction_id,
		// 		price: price,
		// 		target: target_block,
		// 	};

		// 	nft.sale_info = sale_info.clone();		// !! I CAN REMOVE CLONE WHEN I REMOVE SALEINFOSTORE INSERT BELOW

		// 	MultiNFTMap::<T>::insert((&caller, index), nft);

		// 	AuctionHouse::<T>::insert(auction_id, lot);

		// 	// ALLOW THE SELLING OF MULTIPLE SHARES: REQUIRED - A REMAINING SHARE FIELD
		// 	// EACH ACCOUNT SHOULD HAVE ITS OWN STORAGEMAP SHOWING WHAT NFTS ARE FOR SALE IN THE AUCTION HOUSE, THIS WAY MULTIPLE SHARE SALES CAN BE ASSESSED.

		// 	// Self::deposit_event(Event::SomethingStored(something, caller));

		// 	Ok(())
		// }

		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn buy_share(origin: OriginFor<T>, owner: T::AccountId, index: u16) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;
			
		// 	// NOT SURE ABOUT THIS FUNCTION.
		// 	// PERHAPS HAVE ONLY A BUY FUNCTION AND A SELL FUNCTION WITH SHARE OPTION

		// 	// FUNCTION:
		// 	// ALLOW A USER TO REQUEST TO BUY A PROPORTION OF THE NFT ON SALE.
		// 	// ONLY WHEN 100% OF THE SHARE FOR SALE HAS BEEN 
		// 	// THE FUNCTION WAITS UNTIL A 
		// 	// BIDDERS FUNDS MUST BE LOCKED?
		// 	// ON THE SELL FUNCTION - OWNER SETS:
		// 	//	- ALLOW TO SELL SHARES
		// 	//  - ALLOW TO SELL THREE SHARE 
		// 	// PRIORITISES PEOPLE WHO WANT TO OWN LOWER SHARES.

		// 	// Self::deposit_event(Event::SomethingStored(something, caller));

		// 	Ok(())
		// }

		// #[pallet::weight(10_000 + T::DbWeight::get().writes(1))]
		// pub fn transfer_share(origin: OriginFor<T>, from: T::AccountId, to: T::AccountId, index: u16, share: u8) -> DispatchResult {
		// 	let caller = ensure_signed(origin)?;
			
		// 	ensure!(&caller == &from, "You do not own the NFT");

		// 	let mut nft: NFT_<T> = MultiNFTMap::<T>::get((&caller, index)).ok_or("unable to acquire NFT object for transfer")?;

		// 	ensure!(nft.share >= share, "You do not own enough share");

		// 	let share_remaining = nft.share.checked_sub(share).ok_or("unable to reduce share")?;

		// 	let mut nft_buyer = nft.clone();

		// 	nft.share = share_remaining;
		// 	nft_buyer.share = share;

		// 	let recipient_index = NFTCount::<T>::get(&to);
			
		// 	MultiNFTMap::<T>::insert((&from, index), nft);
		// 	MultiNFTMap::<T>::insert((&to, recipient_index), nft_buyer);

		// 	// increase nft count of buyer
		// 	let new_recipient_index = recipient_index.checked_add(1).ok_or("u16 overflow found when incrementing recipient index")?;

		// 	NFTCount::<T>::insert(&to, new_recipient_index);

		// 	// Self::deposit_event(Event::SomethingStored(something, caller));

		// 	Ok(())
		// }
		
		//
		//
		//
		//
		// #############
		// BUILD GUIDELINES:
		// #############
		// File imported through mint function call
		// Hash of file created.
		//
		// Store file on IPFS
		// Get IPFS storage location
		// Store IPFS location data in ipfs_url
		//
		// create object: owner | hash of data | IPFS location
		//
		// encrypt IPFS location (using a password) and store the encrypted IPFS location
		// encrypt the IPFS data prior to loading on IPFS
		//
		// #############
		// STRUCTS:
		// #############
		// #[derive(Encode, Decode)]
		// pub struct TokenInfoTwo<AccountId, Hash>{
		// 	pub owner: AccountId,
		// 	pub nft_id: Hash,
		// 	pub ipfs_url: Vec<u8>,
		// }
		// #[derive(Encode, Decode)]
		// pub struct TokenInfo<AccountId, Hash>{
		// 	pub owner: AccountId,
		// 	pub nft_id: Hash,
		// }
		// #[derive(Encode, Decode)]
		// pub struct AcctInfo<AccountId>{
		// 	pub owner: AccountId,
		// }
		// #[derive(Encode, Decode)]
		// pub struct HshInfo<Hash>{
		// 	pub nft_id: Hash,
		// }
		// #[derive(Encode, Decode)]
		// pub struct TokenInfoFinal{
		// 	pub ipfs_id: Vec<u8>,
		// }
		//
		// #############
		// TYPES:
		// #############
		// pub type TokenInfoOf<T> = TokenInfo<<T as frame_system::Config>::AccountId, <T as Config>::LovelyNumber>;
		// pub type TokenInfoOf<T> = TokenInfo<<T as frame_system::Config>::AccountId, <T as Config>::TokenData>;
		// pub type TokenInfoOf<T> = TokenInfo<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash>;
		// pub type TokenInfoTwoOf<T> = TokenInfoTwo<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash>;
		// pub type AcctInfoOf<T> = AcctInfo<<T as frame_system::Config>::AccountId>;
		// pub type HshInfoOf<T> = HshInfo<<T as frame_system::Config>::Hash>;
		// pub type TokenInfoFinalOf = TokenInfoFinal;
		// pub type NFT_<T> = NFT<<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash>;
		// type LovelyNumber: Get<u32>;

		// #############
		// STORAGE:
		// #############
		// #[pallet::storage]
		// #[pallet::getter(fn something)]
		// pub type Something<T> = StorageValue<_, u32>;

		// #[pallet::storage]
		// #[pallet::getter(fn get_addr)]	
		// pub type Addr<T> = StorageValue<_, <T as frame_system::Config>::AccountId>;

		// #[pallet::storage]
		// #[pallet::getter(fn some_map)]
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, TokenInfoOf<T>>;
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, u32>;
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, T::AccountId, u32, ValueQuery>;

		// #[pallet::storage]
		// pub(super) type SomeDoubleMap<T> = StorageDoubleMap<_, Blake2_128Concat, u32, Blake2_128Concat, <T as frame_system::Config>::AccountId, u32>;
		// pub(super) type SomeDoubleMap<T> = StorageDoubleMap<_, Blake2_128Concat, u32, Blake2_128Concat, T::AccountId, u32, ValueQuery>;

		// #[pallet::storage]
		// #[pallet::getter(fn some_map)]
		// pub(super) type SomeMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, TokenInfoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn some_map_two)]
		// pub(super) type SomeMapTwo<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, TokenInfoTwoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn acct_map)]
		// pub(super) type AcctMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, AcctInfoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn hsh_map)]
		// pub(super) type HshMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, HshInfoOf<T>>;

		// #[pallet::storage]
		// #[pallet::getter(fn main_map)]
		// pub(super) type MainMap<T> = StorageMap<_, Blake2_128Concat, (<T as frame_system::Config>::AccountId, <T as frame_system::Config>::Hash), TokenInfoFinalOf>;

		// #[pallet::storage]
		// #[pallet::getter(fn get_NFT)]
		// pub(super) type NFTMap<T> = StorageMap<_, Blake2_128Concat, <T as frame_system::Config>::AccountId, NFT_<T>>;

		// #############
		// MINT:
		// #############
		// NFTMap::<T>::insert(&caller, &nft);

		// #############
		// MINT FUNCTION: POP AND SWAP
		// #############
		// let last_index_value = NFTCount::<T>::get(&caller);

		// if index != last_index_value {
		// 	let nft_last = MultiNFTMap::<T>::get((&caller, last_index_value)).ok_or("unable to acquire last NFT object for pop and swap")?;
		// 	let nft_elsewhere = MultiNFTMap::<T>::get((&caller, index)).ok_or("unable to acquire last NFT object for pop and swap")?;
		// 	MultiNFTMap::<T>::insert((to.clone(), last_index_value), nft_elsewhere);
		// 	MultiNFTMap::<T>::insert((to.clone(), index), nft_last);
		// }
		// #############
		// MINT FUNCTION: TRANSFER
		// #############
		// ##################################
		// IF EMPTY LIST ELEMENTS ARE NOT CREATED BY ::remove THEN THIS SECTION OF CODE IS NOT NEEDED
		// // the sale created an empty element in the sellers nft list, move the last nft into this empty element.
		// let last_index_value = NFTCount::<T>::get(&caller);
		//
		// if index != last_index_value {
		// 	let last_nft = MultiNFTMap::<T>::get((&from, last_index_value)).ok_or("unable to acquire last NFT object for pop and swap")?;
		// 	MultiNFTMap::<T>::remove((&from, last_index_value));
		// 	MultiNFTMap::<T>::insert((&from, index), last_nft);
		// }
		//
		// // decrease nft count of seller
		// let reduced_index = last_index_value.checked_sub(1).ok_or("u16 overflow found when incrementing recipient index")?;
		// NFTCount::<T>::insert(&from, reduced_index);
		// ##################################

		// #############
		// GENERAL INFORMATION
		// #############
		// DURATION
			// 1 BLOCK = 3 SECONDS
			// 20 BLOCK = 1 MINUTE
			// 1,200 BLOCK = 1 HOUR
			// 28,000 BLOCK = 1 DAY		24 HOURS
			// 201,800 BLOCK = 7 DAYS	168 HOURS
			// 864,000 = 30 DAYS		720 HOURS
	}
}
